H1st Concepts
=============

H1st is designed with the following principles:

.. include:: principles.rst.txt

..  toctree::
    :hidden:
    :maxdepth: 4

    k1st.rst
    a1st.rst
    ai-rule.rst
    object-model.rst
