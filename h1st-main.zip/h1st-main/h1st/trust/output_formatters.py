class OutputFormatters:
    """
    [summary]
    """
