Use-Case Examples
=================
