class ModelException(Exception):
    pass


class GraphException(Exception):
    pass


class SchemaException(Exception):
    pass
