class Debiasable:
    """
    [summary]
    """

    def debias(self, decisions):
        pass  # to be implemented
